
//Найти все натуральные числа,не превосходящие К,
//сумма цифр каждого из которых в некоторой степени дает это число

#include <QApplication>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QtGlobal>
#include <exception>
#include <QStringList>

using namespace std;

class InputExcep : public exception {
public:
    const char* what() const noexcept override {
        return "K must be > 0";
    }
};

class Chislo {

private:
    int a;
    static int sumDigits(int x) {
        int s = 0;
        while (x > 0) { s += x % 10; x /= 10; }
        return s;
    }

public:
    explicit Chislo(int a0) {
        if (a0 <= 0) throw InputExcep();
        a = a0;
    }

    QStringList getRes(int minP = 1, int maxP = 10) const {
        QStringList out;
        for (int i = 1; i <= a; ++i) {
            int s = sumDigits(i);
            for (int p = minP; p <= maxP; p++) {
                qint64 v = qPow(s, p);
                if (v > i) break;
                if (v == i) {
                    out << QString("%1 (sum=%2, power=%3)").arg(i).arg(s).arg(p);
                    break;
                }
            }
        }
        return out;
    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QWidget      window;
    QLineEdit   *inputK   = new QLineEdit(&window);
    QPushButton *btnCalc  = new QPushButton("Calculate", &window);
    QTextEdit   *output   = new QTextEdit(&window);

    inputK->setPlaceholderText("Enter K > 0");
    output->setReadOnly(true);
    output->setPlaceholderText("Найти все натуральные числа,не превосходящие К,сумма цифр каждого из которых в некоторой степени дает это число");
    auto *hLayout = new QHBoxLayout();
    hLayout->addWidget(new QLabel("K:", &window));
    hLayout->addWidget(inputK);

    auto *vLayout = new QVBoxLayout(&window);
    vLayout->addLayout(hLayout);
    vLayout->addWidget(btnCalc);
    vLayout->addWidget(output);

    window.setWindowTitle("finding power of dig sum");
    window.resize(400, 400);
    window.show();

    QObject::connect(btnCalc, &QPushButton::clicked, [&]() {
        output->clear();

        int K = inputK->text().toInt();
        if (K <= 0) {
            QMessageBox::warning(&window, "Enter", "Enter K > 0");
            return;
        }
        Chislo checker(K);
        QStringList res = checker.getRes();
        if (res.isEmpty()) {
            output->append("No valid numbers \n");
        } else {
            output->append(res.join("\n"));
        }

        output ->append("Zherelo");

    });

    return app.exec();
}
