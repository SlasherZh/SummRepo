/*Zherelo
 * Создать класс комната, имеющая площадь. Определить конструктор и метод доступа.
 * Создать класс однокомнатных квартира, содержащий комнату и кухню (ее площадь), этаж
 * (комната содержится в классе однокомнатная квартира). Определить конструкторы, методы доступа.
 * Определить public-производный класс однокомнатных квартир разных городов ( дополнительный параметр - название города).
 * Определить конструкторы, деструктор и функцию печати. */

#include <QApplication>
#include <QtWidgets>
#include <QString>
#include <QVector>
#include <iostream>

class Room {
    double area;
public:
    Room(double a = 0.0) : area(a) {}
    double getArea() const { return area; }
    void setArea(double a) { area = a; }
};

class OneRoomApartment {
protected:
    Room   room;
    double kitchenArea;
    int    floor;
public:
    OneRoomApartment(double roomArea, double kitchenArea, int floor_)
        : room(roomArea), kitchenArea(kitchenArea), floor(floor_) {}
    virtual ~OneRoomApartment() {}
    double getRoomArea()    const { return room.getArea(); }
    double getKitchenArea() const { return kitchenArea; }
    int    getFloor()       const { return floor; }
};

class CityApartment : public OneRoomApartment {
    QString city;
public:
    CityApartment(const QString& city_,
                  double roomArea,
                  double kitchenArea,
                  int floor_)
        : OneRoomApartment(roomArea, kitchenArea, floor_)
        , city(city_)
    {}
    ~CityApartment() override {
        std::cout << "Flat in "
                  << city.toStdString()
                  << " deleted\n";
    }
    QString getCity() const { return city; }
};

class ApartmentWidget : public QWidget {
    QLineEdit      *cityEdit;
    QDoubleSpinBox *roomSpin;
    QDoubleSpinBox *kitchenSpin;
    QSpinBox       *floorSpin;
    QPushButton    *addButton;
    QTableWidget   *table;
    QVector<CityApartment*> apartments;

public:
    ApartmentWidget(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        // Виджет с описанием задания
        QTextEdit *descEdit = new QTextEdit(this);
        descEdit->setReadOnly(true);
        descEdit->setPlainText(
            "* Создать класс комната, имеющая площадь. Определить конструктор и метод доступа.\n"
            "* Создать класс однокомнатных квартира, содержащий комнату и кухню (ее площадь), этаж.\n"
            "* (комната содержится в классе однокомнатная квартира). Определить конструкторы, методы доступа.\n"
            "* Определить public-производный класс однокомнатных квартир разных городов (дополнительный параметр - название города).\n"
            "* Определить конструкторы, деструктор и функцию печати."
            );
        descEdit->setMinimumHeight(120);

        cityEdit = new QLineEdit(this);
        cityEdit->setPlaceholderText("Город");

        roomSpin = new QDoubleSpinBox(this);
        roomSpin->setRange(0.0, 1000.0);
        roomSpin->setSuffix(" м²");
        roomSpin->setDecimals(1);

        kitchenSpin = new QDoubleSpinBox(this);
        kitchenSpin->setRange(0.0, 500.0);
        kitchenSpin->setSuffix(" м²");
        kitchenSpin->setDecimals(1);

        floorSpin = new QSpinBox(this);
        floorSpin->setRange(1, 100);

        addButton = new QPushButton("Добавить квартиру", this);

        table = new QTableWidget(0, 4, this);
        table->setHorizontalHeaderLabels(
            QStringList{ "Город", "Комната (м²)", "Кухня (м²)", "Этаж" }
            );
        table->horizontalHeader()->setSectionResizeMode(
            QHeaderView::Stretch
            );

        auto *formLayout = new QFormLayout;
        formLayout->addRow("Город:",           cityEdit);
        formLayout->addRow("Площадь комнаты:", roomSpin);
        formLayout->addRow("Площадь кухни:",   kitchenSpin);
        formLayout->addRow("Этаж:",            floorSpin);
        formLayout->addRow("",                  addButton);

        auto *mainLayout = new QVBoxLayout(this);
        mainLayout->addWidget(descEdit);
        mainLayout->addLayout(formLayout);
        mainLayout->addWidget(table);

        connect(addButton, &QPushButton::clicked, this, [this]() {
            if (cityEdit->text().isEmpty()) {
                cityEdit->setFocus();
                return;
            }
            addApartment(
                cityEdit->text(),
                roomSpin->value(),
                kitchenSpin->value(),
                floorSpin->value()
                );
            cityEdit->clear();
            roomSpin->setValue(0.0);
            kitchenSpin->setValue(0.0);
            floorSpin->setValue(1);
            cityEdit->setFocus();
        });
    }

    ~ApartmentWidget() override {
        qDeleteAll(apartments);
        apartments.clear();
    }

    void addApartment(const QString& city,
                      double roomArea,
                      double kitchenArea,
                      int floor)
    {
        CityApartment *apt = new CityApartment(
            city, roomArea, kitchenArea, floor
            );
        apartments.append(apt);

        int row = table->rowCount();
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(apt->getCity()));
        table->setItem(row, 1, new QTableWidgetItem(
                                   QString::number(apt->getRoomArea(), 'f', 1)
                                   ));
        table->setItem(row, 2, new QTableWidgetItem(
                                   QString::number(apt->getKitchenArea(), 'f', 1)
                                   ));
        table->setItem(row, 3, new QTableWidgetItem(
                                   QString::number(apt->getFloor())
                                   ));
    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    ApartmentWidget *w = new ApartmentWidget;
    w->addApartment("Minsk", 25.5, 12.0, 5);
    w->addApartment("Grodno", 28.0, 10.5, 3);

    w->setWindowTitle("Список однокомнатных квартир");
    w->resize(600, 600);
    w->show();

    return app.exec();
}
