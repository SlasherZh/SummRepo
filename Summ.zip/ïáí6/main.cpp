//Zherelo
#include <QApplication>
#include <QMainWindow>
#include <QtWidgets>
#include <QDataStream>
#include <QFile>

struct Shape {
    enum Type { Line, Rect, Ellipse } type;
    QPointF p1, p2;
    QColor color;
    int   penWidth;

    friend QDataStream& operator<<(QDataStream& out, const Shape& s) {
        out << static_cast<qint32>(s.type)
        << s.p1 << s.p2
        << s.color << s.penWidth;
        return out;
    }
    friend QDataStream& operator>>(QDataStream& in, Shape& s) {
        qint32 t;
        in >> t >> s.p1 >> s.p2 >> s.color >> s.penWidth;
        s.type = static_cast<Shape::Type>(t);
        return in;
    }
};

// Виджет для рисования
class Canvas : public QWidget {
    Q_OBJECT

private:
    QVector<Shape> shapes;
    Shape::Type    currentType = Shape::Line;
    bool           drawing     = false;
    QPointF        startPt, endPt;
    QColor         penColor;
    int            penWidth;

    void drawShape(QPainter& p, const Shape& s) {
        switch (s.type) {
        case Shape::Line:
            p.drawLine(s.p1, s.p2);
            break;
        case Shape::Rect:
            p.drawRect(QRectF(s.p1, s.p2));
            break;
        case Shape::Ellipse:
            p.drawEllipse(QRectF(s.p1, s.p2));
            break;
        }
    }

protected:
    void paintEvent(QPaintEvent*) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);

        for (auto& s : shapes) {
            p.setPen(QPen(s.color, s.penWidth));
            if (s.type == Shape::Rect || s.type == Shape::Ellipse)
                p.setBrush(s.color);
            else
                p.setBrush(Qt::NoBrush);

            drawShape(p, s);
        }

        if (drawing) {
            Shape tmp{ currentType, startPt, endPt, penColor, penWidth };
            p.setPen(QPen(tmp.color, tmp.penWidth, Qt::DashLine));
            p.setBrush(Qt::NoBrush);
            drawShape(p, tmp);
        }
    }


    void mousePressEvent(QMouseEvent* ev) override {
        if (ev->button() == Qt::LeftButton) {
            startPt = ev->pos();
            endPt   = startPt;
            drawing = true;
        }
    }

    void mouseMoveEvent(QMouseEvent* ev) override {
        if (drawing) {
            endPt = ev->pos();
            update();
        }
    }

    void mouseReleaseEvent(QMouseEvent* ev) override {
        if (ev->button() == Qt::LeftButton && drawing) {
            shapes.push_back({currentType, startPt, ev->pos(), penColor, penWidth});
            drawing = false;
            update();
        }
    }



public:
    Canvas(QWidget* parent = nullptr) : QWidget(parent) {
        setAttribute(Qt::WA_StaticContents);
        penColor = Qt::black;
        penWidth = 1;
    }

    void setShapeType(Shape::Type t) { currentType = t; }
    void setPenColor(const QColor& c) { penColor = c; }
    void setPenWidth(int w)          { penWidth = w; }

    bool saveToFile(const QString& fileName) {
        QFile file(fileName);
        if (!file.open(QIODevice::WriteOnly)) return false;
        QDataStream out(&file);
        out << qint32(shapes.size());
        for (auto& s: shapes) out << s;
        return true;
    }

    bool loadFromFile(const QString& fileName) {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) return false;
        QDataStream in(&file);
        qint32 count;
        in >> count;
        shapes.clear();
        for (qint32 i = 0; i < count; ++i) {
            Shape s;
            in >> s;
            shapes.push_back(s);
        }
        update();
        return true;
    }
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget* parent = nullptr) : QMainWindow(parent) {
        canvas = new Canvas;
        setCentralWidget(canvas);

        createActions();
        createMenus();
        createToolBar();

        setWindowTitle("Vector Graphics Editor");
        resize(800, 600);
    }

private slots:
    void setLine()    { canvas->setShapeType(Shape::Line); }
    void setRect()    { canvas->setShapeType(Shape::Rect); }
    void setEllipse() { canvas->setShapeType(Shape::Ellipse); }

    void chooseColor() {
        QColor c = QColorDialog::getColor(canvas->palette().color(QWidget::foregroundRole()), this);
        if (c.isValid()) {
            canvas->setPenColor(c);
            colorAct->setIcon(createColorIcon(c));
        }
    }

    void changeWidth(int idx) {
        // combobox items: "1","2","3","5","8","12"
        int w = comboWidth->currentText().toInt();
        canvas->setPenWidth(w);
    }

    void save() {
        QString fn = QFileDialog::getSaveFileName(this, "Save File", "", "*.vgd");
        if (!fn.isEmpty()) canvas->saveToFile(fn);
    }

    void load() {
        QString fn = QFileDialog::getOpenFileName(this, "Open File", "", "*.vgd");
        if (!fn.isEmpty()) canvas->loadFromFile(fn);
    }

private:
    Canvas*      canvas;
    QAction*     saveAct;
    QAction*     loadAct;
    QAction*     lineAct;
    QAction*     rectAct;
    QAction*     ellipseAct;
    QAction*     colorAct;
    QComboBox*   comboWidth;

    void createActions() {
        saveAct    = new QAction("Save...", this);
        loadAct    = new QAction("Load...", this);
        lineAct    = new QAction("Line", this);
        rectAct    = new QAction("Rectangle", this);
        ellipseAct = new QAction("Ellipse", this);
        colorAct   = new QAction(createColorIcon(Qt::black), "Color", this);

        connect(saveAct,    &QAction::triggered, this, &MainWindow::save);
        connect(loadAct,    &QAction::triggered, this, &MainWindow::load);
        connect(lineAct,    &QAction::triggered, this, &MainWindow::setLine);
        connect(rectAct,    &QAction::triggered, this, &MainWindow::setRect);
        connect(ellipseAct, &QAction::triggered, this, &MainWindow::setEllipse);
        connect(colorAct,   &QAction::triggered, this, &MainWindow::chooseColor);
    }

    void createMenus() {
        QMenu* fileMenu  = menuBar()->addMenu("File");
        fileMenu->addAction(saveAct);
        fileMenu->addAction(loadAct);

        QMenu* shapeMenu = menuBar()->addMenu("Shape");
        shapeMenu->addAction(lineAct);
        shapeMenu->addAction(rectAct);
        shapeMenu->addAction(ellipseAct);
    }

    void createToolBar() {
        QToolBar* tb = addToolBar("Tools");

        // Цвет
        tb->addAction(colorAct);

        // Толщина
        QLabel* lbl = new QLabel(" Width: ", this);
        tb->addWidget(lbl);

        comboWidth = new QComboBox(this);
        comboWidth->addItems({"1","2","3","5","8","12"});
        comboWidth->setCurrentIndex(0);
        connect(comboWidth, QOverload<int>::of(&QComboBox::currentIndexChanged),
                this, &MainWindow::changeWidth);
        tb->addWidget(comboWidth);
    }

    QIcon createColorIcon(const QColor& c) {
        QPixmap pix(16,16);
        pix.fill(c);
        return QIcon(pix);
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    MainWindow w;
    w.show();
    return app.exec();
}

#include "main.moc"
