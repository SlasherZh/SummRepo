//Zherelo
#include <QApplication>
#include <QtWidgets>
#include <QRegularExpression>
#include <QtMath>

//Task1Widget
class Task1Widget : public QWidget {
public:
    Task1Widget(QWidget *parent = nullptr) : QWidget(parent) {
        auto *inputK = new QLineEdit;
        auto *btn    = new QPushButton("Calc DigSum^p == n");
        auto *out    = new QTextEdit;
        out->setReadOnly(true);
        out->setPlaceholderText("Найти все натуральные числа,не превосходящие К,сумма цифр каждого из которых в некоторой степени дает это число");
        inputK->setPlaceholderText("Enter K > 0");
        inputK->setValidator(new QIntValidator(1, 1000000000, this));

        auto *lay = new QVBoxLayout(this);
        lay->addWidget(inputK);
        lay->addWidget(btn);
        lay->addWidget(out);

        connect(btn, &QPushButton::clicked, this, [=]() {
            out->clear();
            int K = inputK->text().toInt();
            if (K <= 0) {
                QMessageBox::warning(this, "Error", "Enter K>0");
                return;
            }

            auto sumDigits = [](int x) {
                int s = 0;
                while (x) { s += x % 10; x /= 10; }
                return s;
            };

            for (int i = 1; i <= K; ++i) {
                int s = sumDigits(i);
                for (int p = 1; p <= 10; ++p) {
                    qint64 v = qPow(s, p);
                    if (v > i) break;
                    if (v == i) {
                        out->append(
                            QString("%1 (sum=%2, p=%3)").arg(i).arg(s).arg(p)
                            );
                        break;
                    }
                }
            }
            if (out->toPlainText().isEmpty())
                out->append("No solutions");
            out->append("\n Zherelo");
        });

    }
};

//Task2Widget
class Task2Widget : public QWidget {
public:
    Task2Widget(QWidget *parent = nullptr) : QWidget(parent) {
        auto *rows = new QSpinBox;
        auto *cols = new QSpinBox;
        rows->setRange(1, 100);
        cols->setRange(1, 100);

        auto *btn    = new QPushButton("Rearrange Matrix");
        auto *inMat  = new QTextEdit;
        auto *outMat = new QTextEdit;

        inMat->setPlaceholderText("One matrix row per line, nums sep by spaces");
        outMat->setReadOnly(true);
        outMat->setPlaceholderText("Задание:  У матрицы A=(aij) ,  i=1..n, j=1..m, n,m<=100, каждом столбце и в каждой строке имеется единственный нуль.Переставить строки матрицы таким образом, чтобы  элементы равные нулю стояли на главной диагонали.");

        auto *top = new QHBoxLayout;
        top->addWidget(new QLabel("Rows:"));
        top->addWidget(rows);
        top->addWidget(new QLabel("Cols:"));
        top->addWidget(cols);
        top->addStretch();
        top->addWidget(btn);

        auto *lay = new QVBoxLayout(this);
        lay->addLayout(top);
        lay->addWidget(inMat);
        lay->addWidget(outMat);

        connect(btn, &QPushButton::clicked, this, [=]() {
            outMat->clear();
            int R = rows->value(), C = cols->value();
            auto lines = inMat->toPlainText()
                             .split('\n', Qt::SkipEmptyParts);
            if (lines.size() != R) {
                QMessageBox::warning(this, "Error", "Wrong number of rows");
                return;
            }

            QVector<QVector<int>> M(R, QVector<int>(C));
            for (int i = 0; i < R; ++i) {
                auto colmn = lines[i]
                                .split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
                if (colmn.size() != C) {
                    i++;
                    QMessageBox::warning(this, "Error",
                                         QString("Line %1: expected %2 cols, got %3").arg(i).arg(C).arg(colmn.size()));
                    return;
                }
                for (int j = 0; j < C; ++j) {
                    bool ok;
                    M[i][j] = colmn[j].toInt(&ok);
                    if (!ok) {
                        QMessageBox::warning(this,"Error","Bad number");
                        return;
                    }
                }
            }

            // rearrange so that each zero lands on diag
            QVector<bool> usedR(R, false), usedC(C, false);
            for (int i = 0; i < qMin(R, C); ++i) {
                for (int j = 0; j < R; ++j) {
                    if (M[j][i] == 0 && !usedR[j] && !usedC[i]) {
                        if (j != i) std::swap(M[i], M[j]);
                        usedR[i] = usedC[i] = true;
                        break;
                    }
                }
            }

            // print result
            for (int i = 0; i < R; ++i) {
                QStringList row;
                for (int j = 0; j < C; ++j)
                    row << QString::number(M[i][j]);
                outMat->append(row.join(' '));
            }
            outMat->append("Zherelo");
        });
    }
};

//Task3Widget
class Task3Widget : public QWidget {
public:
    Task3Widget(QWidget *parent = nullptr) : QWidget(parent) {
        auto *n     = new QSpinBox;
        n->setRange(1, 10000);
        auto *btn   = new QPushButton("Find Common");
        auto *xEdit = new QTextEdit;
        auto *yEdit = new QTextEdit;
        auto *zEdit = new QTextEdit;
        auto *res   = new QLabel;

        xEdit->setPlaceholderText("Array X: nums sep by spaces");
        yEdit->setPlaceholderText("Array Y");
        zEdit->setPlaceholderText(" Задание: Даны  три  неубывающих массива X=(xi),i=1..n, Y=(yi),i=1..m, Z=(zi), i=1..d, n=m=d. Некоторое  число содержится  в каждом из трех  этих  массивов. Найти одно из таких чисел.");

        auto *top = new QHBoxLayout;
        top->addWidget(new QLabel("N:"));
        top->addWidget(n);
        top->addStretch();
        top->addWidget(btn);

        auto *grid = new QGridLayout;
        grid->addWidget(new QLabel("X:"), 0, 0);
        grid->addWidget(xEdit, 0, 1);
        grid->addWidget(new QLabel("Y:"), 1, 0);
        grid->addWidget(yEdit, 1, 1);
        grid->addWidget(new QLabel("Z:"), 2, 0);
        grid->addWidget(zEdit, 2, 1);

        auto *lay = new QVBoxLayout(this);
        lay->addLayout(top);
        lay->addLayout(grid);
        lay->addWidget(new QLabel("Result:"));
        lay->addWidget(res);

        connect(btn, &QPushButton::clicked, this, [=]() {
            res->clear();
            int N = n->value();
            auto parse = [&](QTextEdit *te){
                auto toks = te->toPlainText()
                .split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);
                if (toks.size() != N) return QVector<int>();
                QVector<int> a; a.reserve(N);
                for (auto &s : toks) {
                    bool ok;
                    int v = s.toInt(&ok);
                    if (!ok) return QVector<int>();
                    a.push_back(v);
                }
                return a;
            };
            auto X = parse(xEdit), Y = parse(yEdit), Z = parse(zEdit);
            if (X.size()!=N || Y.size()!=N || Z.size()!=N) {
                QMessageBox::warning(this, "Error", "Each array must have N elems");
                return;
            }
            int i=0,j=0,k=0, common=-1;
            while (i<N && j<N && k<N) {
                if (X[i]==Y[j] && Y[j]==Z[k]) {
                    common = X[i];
                    break;
                }
                int m = std::min({X[i], Y[j], Z[k]});
                if (X[i]==m) ++i;
                if (Y[j]==m) ++j;
                if (Z[k]==m) ++k;
            }
            res->setText(common<0 ? "No common element": QString::number(common));
        });

    }
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QMainWindow window;
    auto *toolbar = window.addToolBar("Tasks");
    toolbar->addWidget(new QLabel("Select task:"));

    auto *combo = new QComboBox;
    combo->addItems({
        "1) DigSum^p == n",
        "2) Matrix zeros→diag",
        "3) Common in 3 sorted arrays"
    });
    toolbar->addWidget(combo);
    auto *stack = new QStackedWidget;
    stack->addWidget(new Task1Widget);
    stack->addWidget(new Task2Widget);
    stack->addWidget(new Task3Widget);

    //combo → stack
    QObject::connect(combo,
                     QOverload<int>::of(&QComboBox::currentIndexChanged),stack, &QStackedWidget::setCurrentIndex);
    window.setCentralWidget(stack);
    window.resize(700, 500);
    window.setWindowTitle("Multi-Task Qt Widget");
    window.show();

    return app.exec();
}
