//Zherelo задание из лабы 6
#include <QtWidgets>
#include <QApplication>
#include <QFile>
#include <QDataStream>
#include <QTextStream>
#include <QVector>
#include <algorithm>

struct Student {
    long   num;
    char   name[10];
    int    group;
    double grade;

    bool operator==(const Student& o) const {
        return num == o.num
               && std::strcmp(name, o.name) == 0
               && group == o.group
               && grade == o.grade;
    }
};

QDataStream& operator<<(QDataStream& out, const Student& s) {
    out.writeRawData(reinterpret_cast<const char*>(&s), sizeof(s));
    return out;
}

QDataStream& operator>>(QDataStream& in, Student& s) {
    in.readRawData(reinterpret_cast<char*>(&s), sizeof(s));
    return in;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QVector<Student> students1;
    QVector<Student> students2;
    QVector<Student> result;

    // Создание тестовых бинарных файлов
    {
        QVector<Student> s1 = {
            {5, "Alice",   1, 4.5},
            {2, "Bob",     1, 3.7},
            {4, "Charlie", 2, 4.2}
        };
        QVector<Student> s2 = {
            {3, "David", 2, 3.8},
            {2, "Bob",   1, 3.7},
            {1, "Eve",   3, 4.9}
        };
        QFile f1("students1.bin"), f2("students2.bin");
        if (f1.open(QIODevice::WriteOnly)) {
            QDataStream out(&f1);
            for (auto& s : s1) out << s;
            f1.close();
        }
        if (f2.open(QIODevice::WriteOnly)) {
            QDataStream out(&f2);
            for (auto& s : s2) out << s;
            f2.close();
        }
    }

    QMainWindow window;
    window.setWindowTitle("Student Manager");

    auto *view  = new QTableView(&window);
    auto *model = new QStandardItemModel(&window);
    view->setModel(model);
    window.setCentralWidget(view);

    // Функция обновления таблицы на экране
    auto updateTable = [&](){
        model->clear();
        model->setHorizontalHeaderLabels({ "ID", "Name", "Group", "Grade" });
        for (auto& s : result) {
            QList<QStandardItem*> row;
            row << new QStandardItem(QString::number(s.num))
                << new QStandardItem(QString::fromLatin1(s.name))
                << new QStandardItem(QString::number(s.group))
                << new QStandardItem(QString::number(s.grade));
            model->appendRow(row);
        }
    };

    auto loadBinary = [&](){
        QString f1 = QFileDialog::getOpenFileName(&window, "Open students1.bin");
        QString f2 = QFileDialog::getOpenFileName(&window, "Open students2.bin");
        if (f1.isEmpty() || f2.isEmpty()) return;

        auto load = [&](const QString& fn, QVector<Student>& vec){
            vec.clear();
            QFile f(fn);
            if (!f.open(QIODevice::ReadOnly)) {
                QMessageBox::warning(&window, "Error", "Cannot open " + fn);
                return;
            }
            QDataStream in(&f);
            Student s;
            while (!in.atEnd()) { in >> s; vec.append(s); }
            f.close();
        };

        load(f1, students1);
        load(f2, students2);
        result = students1;
        updateTable();
    };

    auto saveBinary = [&](){
        QString fn = QFileDialog::getSaveFileName(
            &window, "Save result binary", "", "Binary files (*.bin)");
        if (fn.isEmpty()) return;
        if (!fn.endsWith(".bin", Qt::CaseInsensitive))
            fn += ".bin";

        QFile f(fn);
        if (!f.open(QIODevice::WriteOnly)) {
            QMessageBox::warning(&window, "Error", "Cannot save " + fn);
            return;
        }
        QDataStream out(&f);
        for (auto& s : result) out << s;
    };

    auto saveText = [&](){
        QString fn = QFileDialog::getSaveFileName(
            &window, "Save as text", "", "Text files (*.txt)");
        if (fn.isEmpty()) return;
        if (!fn.endsWith(".txt", Qt::CaseInsensitive))
            fn += ".txt";

        QFile f(fn);
        if (!f.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::warning(&window, "Error", "Cannot save " + fn);
            return;
        }
        QTextStream out(&f);
        for (auto& s : result) {
            out << s.num << " "
                << s.name << " "
                << s.group << " "
                << s.grade << "\n";
        }
    };

    auto unionOp = [&](){
        result = students1;
        for (auto& s : students2)
            if (!result.contains(s)) result.append(s);
        updateTable();
    };
    auto intersectOp = [&](){
        result.clear();
        for (auto& s : students1)
            if (students2.contains(s)) result.append(s);
        updateTable();
    };
    auto diffOp = [&](){
        result.clear();
        for (auto& s : students1)
            if (!students2.contains(s)) result.append(s);
        updateTable();
    };

    auto sortById = [&](){
        std::sort(result.begin(), result.end(),
                  [](auto& a, auto& b){ return a.num < b.num; });
        updateTable();
    };
    auto sortByGroup = [&](){
        std::sort(result.begin(), result.end(),
                  [](auto& a, auto& b){ return a.group < b.group; });
        updateTable();
    };
    auto sortByGroupName = [&](){
        std::sort(result.begin(), result.end(),
                  [](auto& a, auto& b){
                      return a.group == b.group
                                 ? std::strcmp(a.name, b.name) < 0 : a.group < b.group;
                  });
        updateTable();
    };

    QMenu *fileMenu = window.menuBar()->addMenu("File");
    fileMenu->addAction("Load Binary",   loadBinary);
    fileMenu->addAction("Save Binary",   saveBinary);
    fileMenu->addAction("Save as Text",  saveText);

    QMenu *opMenu = window.menuBar()->addMenu("Operations");
    opMenu->addAction("Union",        unionOp);
    opMenu->addAction("Intersection", intersectOp);
    opMenu->addAction("Difference",   diffOp);

    QMenu *sortMenu = window.menuBar()->addMenu("Sort");
    sortMenu->addAction("By ID",             sortById);
    sortMenu->addAction("By Group",          sortByGroup);
    sortMenu->addAction("By Group and Name", sortByGroupName);

    window.resize(600, 400);
    window.show();

    return a.exec();
}
