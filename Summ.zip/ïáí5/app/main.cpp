#include <QApplication>
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include "Chislo.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QWidget      window;
    QLineEdit   *inputK   = new QLineEdit(&window);
    QPushButton *btnCalc  = new QPushButton("Calculate", &window);
    QTextEdit   *output   = new QTextEdit(&window);

    inputK->setPlaceholderText("Enter K > 0");
    output->setReadOnly(true);
    output->setPlaceholderText("Найти все натуральные числа, не превосходящие K, сумма цифр которых в степени дает само число");

    auto *hLayout = new QHBoxLayout();
    hLayout->addWidget(new QLabel("K:", &window));
    hLayout->addWidget(inputK);

    auto *vLayout = new QVBoxLayout(&window);
    vLayout->addLayout(hLayout);
    vLayout->addWidget(btnCalc);
    vLayout->addWidget(output);

    window.setWindowTitle("Finding power of digit sum");
    window.resize(400, 400);
    window.show();

    QObject::connect(btnCalc, &QPushButton::clicked, [&]() {
        output->clear();
        bool ok;
        int K = inputK->text().toInt(&ok);
        if (!ok || K <= 0) {
            QMessageBox::warning(&window, "Invalid Input", "Enter a valid K > 0");
            return;
        }

        try {
            Chislo checker(K);
            QStringList res = checker.getRes();
            if (res.isEmpty()) {
                output->append("No valid numbers found.\n");
            } else {
                output->append(res.join("\n"));
            }
            output->append("\nZherelo");
        } catch (const InputExcep &e) {
            QMessageBox::critical(&window, "Error", e.what());
        }
    });

    return app.exec();
}
