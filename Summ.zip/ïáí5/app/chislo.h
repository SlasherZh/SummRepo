#ifndef CHISLO_H
#define CHISLO_H

#include <QStringList>

class InputExcep : public std::exception {
public:
    const char* what() const noexcept override {
        return "K must be > 0";
    }
};

class Chislo {
private:
    int a;
    static int sumDigits(int x);

public:
    explicit Chislo(int a0);
    QStringList getRes(int minP = 1, int maxP = 10) const;
};

#endif // CHISLO_H
