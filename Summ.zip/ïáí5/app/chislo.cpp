#include "Chislo.h"
#include "qmath.h"
#include <QtGlobal>
#include <QString>

Chislo::Chislo(int a0) {
    if (a0 <= 0) throw InputExcep();
    a = a0;
}

int Chislo::sumDigits(int x) {
    int s = 0;
    while (x > 0) {
        s += x % 10;
        x /= 10;
    }
    return s;
}

QStringList Chislo::getRes(int minP, int maxP) const {
    QStringList out;
    for (int i = 1; i <= a; ++i) {
        int s = sumDigits(i);
        for (int p = minP; p <= maxP; ++p) {
            qint64 v = qPow(s, p);
            if (v > i) break;
            if (v == i) {
                out << QString("%1 (sum=%2, power=%3)").arg(i).arg(s).arg(p);
                break;
            }
        }
    }
    return out;
}
