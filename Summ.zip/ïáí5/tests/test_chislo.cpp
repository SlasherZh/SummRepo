#include <QtTest>
#include "../app/Chislo.h"

class TestChislo : public QObject {
    Q_OBJECT

private slots:
    // Проверяем getRes на небольшом K
    void test_getRes_data() {
        QTest::addColumn<int>("K");
        QTest::addColumn<QStringList>("expected");

        // 512 = (5+1+2)^3 = 8^3
        QTest::newRow("512") << 600
                             << (QStringList() << "512 (sum=8, power=3)");
    }

    void test_getRes() {
        QFETCH(int, K);
        QFETCH(QStringList, expected);

        Chislo c(K);
        QStringList actual = c.getRes();
        // проверяем, что все ожидания есть в результирующем списке
        for (auto &row : expected) {
            QVERIFY(actual.contains(row));
        }
    }

    // Дополнительный тест: пустой результат
    void test_noResult() {
        Chislo c(1);
        QStringList res = c.getRes();
        QVERIFY(res.contains("1 (sum=1, power=1)"));
    }
};

QTEST_APPLESS_MAIN(TestChislo)
#include "test_chislo.moc"
